"""jenkins_cli_tool - Jenkins CLI Tool"""

__version__ = '0.1.0'
__author__ = 'Corentin Hermet <chermet@axway.com>'
__all__ = []
