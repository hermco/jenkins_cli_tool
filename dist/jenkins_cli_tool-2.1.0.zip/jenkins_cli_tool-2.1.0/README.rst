jenkins_cli_tool
================

Jenkins CLI Tool

Usage
-----

Installation
------------

Requirements
^^^^^^^^^^^^

Compatibility
-------------

Licence
-------

Authors
-------

`jenkins_cli_tool` was written by `Corentin Hermet <chermet@axway.com>`_.
